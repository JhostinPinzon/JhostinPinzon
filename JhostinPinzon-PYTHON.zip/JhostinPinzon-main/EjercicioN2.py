celsius = float(input("Ingresa los grados Celsius: "))
fahrenheit = celsius * 1.8 + 32
print("Grados Fahrenheit:", fahrenheit)
