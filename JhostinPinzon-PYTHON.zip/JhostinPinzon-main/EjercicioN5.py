x = input("Ingresa el valor de x: ")
y = input("Ingresa el valor de y: ")
x, y = y, x
print("Nuevo valor de x:", x)
print("Nuevo valor de y:", y)
