salario_base = float(input("Ingresa el salario base: "))
bono = salario_base * 0.10
salario_total = salario_base + bono
print("El salario total con bonificación es:", salario_total)
