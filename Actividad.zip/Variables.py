# 1. Intercambio sin variable auxiliar
a = 5
b = 10
a, b = b, a

# 2. Suma de cuadrados
a = 5
b = 3
c = a**2 + b**2

# 3. Conversión de tipos
n = 7
n_str = str(n)#convierte a cadena
n_float = float(n_str)
n_int = int(n_float)
print(n_str, n_float, n_int)

# 4. Redondeo y formato
numero = 17.8567
resultado = round(numero, 2)
print(f"Resultado: {str(resultado)}")

# 5. Concatenación de variables
nombre = "Juan"
edad = 25
mensaje = f"Hola, mi nombre es {nombre} y tengo {edad} años."
print(mensaje)

# 6. Cálculo de edad actual
anio_actual = 2025
anio_nacimiento = 2000
edad = anio_actual - anio_nacimiento
print(f"Tienes {edad} años.")

# 7. Cuenta regresiva con variables
contador = 10
while contador >= 0:
    print(contador)
    contador -= 1

# 8. Valor absoluto sin usar abs()
x = -15
if x < 0:
    x = -x
print(x)

# 9. Incremento/decremento según paridad
n = 8
if n % 2 == 0:
    n += 1
else:
    n -= 1
print(n)

# 10. Máximo entre tres números sin usar max()
a, b, c = 10, 20, 15
mayor = a
if b > mayor:
    mayor = b
if c > mayor:
    mayor = c
print("Mayor:", mayor)
