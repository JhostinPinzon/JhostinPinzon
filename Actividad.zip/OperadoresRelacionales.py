# 11. Verificación de rango
x = 50
print(10 <= x <= 100)

# 12. Comparación de strings (ignorar mayúsculas)
a = "Hola"
b = "hola"
print(a.lower() == b.lower())

# 13. Igualdad entre tres variables
a, b, c = 5, 5, 5
print(a == b == c)

# 14. Presencia en lista
lista = [1, 3, 5, 7, 9]
x = 5
print(x in lista)

# 15. Divisibilidad por 3 y 5
n = 30
print(n % 3 == 0 and n % 5 == 0)

# 16. Números en orden estricto
a, b, c = 1, 2, 3
print(a < b < c)

# 17. Comparación doble
x = 5
a = 1
b = 10
print(a < x < b)

# 18. Relación proporcional
a = 10
b = 5
print(a == 2 * b)

# 19. Cambio de signo si negativo
x = -8
if x < 0:
    x = -x
print(x)

# 20. Detección de tipo
x = 3.14
if isinstance(x, int):
    print("int")
elif isinstance(x, float):
    print("float")
elif isinstance(x, str):
    print("str")
